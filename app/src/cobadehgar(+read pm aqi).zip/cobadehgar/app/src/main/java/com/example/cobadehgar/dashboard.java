package com.example.cobadehgar;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DashboardActivity extends AppCompatActivity {

    private DatabaseReference debuRef;
    private DatabaseReference udaraRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_dashboard);

        // Ngambil referensi ke Firebase Database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        debuRef = database.getReference("sensor/debu");
        udaraRef = database.getReference("sensor/udara");

        // Ngeread data debu dari Firebase Database
        debuRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Ambil nilai debu
                String nilaiDebu = dataSnapshot.getValue(String.class);

                // Buat ngeread nilai debu pada TextView dengan ID aqilevel
                TextView apilevelTextView = findViewById(R.id.aqilevel);
                apilevelTextView.setText(getString(R.string.aqiinfo, nilaiDebu));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Menangani kesalahan saat membaca data debu
            }
        });

        // Membaca data udara dari Firebase Database
        udaraRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Mendapatkan nilai udara
                String nilaiUdara = dataSnapshot.getValue(String.class);

                // Menampilkan nilai udara pada TextView dengan ID pm10
                TextView pm10TextView = findViewById(R.id.pm10);
                pm10TextView.setText(getString(R.string.pminfo, nilaiUdara));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Menangani kesalahan saat membaca data udara
            }
        });
    }
}
