package com.example.cobadehgar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class home_fr extends AppCompatActivity {

    TextView username;
    Button dashboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_home);

        username = findViewById(R.id.useremail);
        dashboard = findViewById(R.id.detailbtn);

        dashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                username.setText(intent.getStringExtra("Dataemail"));
                Intent maju = new Intent(home_fr.this, dashboard.class);
                startActivity(maju);
            }
        });

        String statusInfo = getString(R.string.status_info_bar);
        TextView textViewCard = findViewById(R.id.textViewCard);
        textViewCard.setText(statusInfo);
    }
}
